const menuBar = document.querySelector('[data-menu="navMenu"]');
const menuBtn = document.querySelector('[data-button="menubtnAttribute"]');

const closeBtn = document.querySelector('[data-close-btn="closebtnAttribute"]')

menuBtn.addEventListener('click', function(){
    if (menuBar.style.transform === 'translateX(100%)' || menuBar.style.transform === '') {
        menuBar.style.transform = 'translateX(0%)';
    }
});



closeBtn.addEventListener('click', function(){
            menuBar.style.transform = 'translateX(100%)';
        });
        
 










const htmlBody = document.querySelector('body');
const themeBtn = document.querySelector('[data-darkmode="theme"]');
const navBar = document.querySelector('nav');
const menuNavBar = document.querySelector('ul');
const textAndIcons = document.querySelectorAll('a, h1, h2, h3, i, p, article, footer');
const dropdownMenu = document.querySelectorAll('.dropdown-menu');




let isDarkMode = false;

themeBtn.addEventListener('click', function(){
    isDarkMode = !isDarkMode;

    if (isDarkMode) {
        htmlBody.style.backgroundColor = '#000000';
        htmlBody.style.color = '#ffffff';
        navBar.style.backgroundColor = '#0f0f0f';
        navBar.style.boxShadow = ' 2px 4px 6px #ffffff57 ';
        navBar.style.color = '#ffeaff';  
        menuNavBar.style.backgroundColor = '#0f0f0f';
        textAndIcons.forEach(element => {
            element.style.color = '#ffffff';
        });
         dropdownMenu.forEach(element => {
             element.style.backgroundColor = '#0f0f0f';
         })
        
    } else {
        htmlBody.style.backgroundColor = '#ffffff';
        htmlBody.style.color = '#ffbd40';
        navBar.style.backgroundColor = '#f8f9fa';
        navBar.style.boxShadow = '2px 4px 6px #00000014';
        navBar.style.color = '#000000';
        menuNavBar.style.backgroundColor = '#ffffff';
        textAndIcons.forEach(element => {
            element.style.color = '#0f0f0f';
        });
        
        dropdownMenu.forEach(element => {
             element.style.backgroundColor = '#ffffff';
         });
        
    }
});







const dropdownMenus = document.querySelectorAll('[data-dropdown-menu="dropdown-menu"]');
const dropdownBtns = document.querySelectorAll('[data-dropdownBtn="dropdownBtn"]');

dropdownBtns.forEach(function(dropdownBtn, index) {
    let dropdownClose = true;
    dropdownBtn.addEventListener('click', function() {
        dropdownMenus.forEach(function(element, i) {
            if (i !== index) {
                element.style.display = 'none';
                element.style.opacity = '0';
                element.style.transition = ' 0.5s';
            }
        });
        dropdownClose = !dropdownClose;
        if (dropdownClose) {
            dropdownMenus[index].style.display = 'none';
            dropdownMenus[index].style.opacity = '0';
            dropdownMenus[index].style.transition = ' 0.5s';
        } else {
            dropdownMenus[index].style.display = 'block';
            dropdownMenus[index].style.opacity = '1';
            dropdownMenus[index].style.transition = ' 0.5s';
        }
    });
});